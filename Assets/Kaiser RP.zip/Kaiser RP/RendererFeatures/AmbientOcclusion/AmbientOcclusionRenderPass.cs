using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.PlayerLoop;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class AmbientOcclusionRenderPass : ScriptableRenderPass
{
    private readonly KaiserAmbientOcclusion.Settings settings;
    private readonly RandomSampler randomSampler;
    private class AmbientOcclusion_Output
    {
        // public static int ColorMask = Shader.PropertyToID("AO_ColorMask");
        public static RTHandle ColorMask;
        public static RTHandle TemporalPrev;
        public static RTHandle TemporalCurr;
        public static RTHandle SpatialOut;
    }

    private static readonly float[] temporalRotations = { 60, 300, 180, 240, 120, 0 };
    private static readonly float[] spatialOffsets = { 0, 0.5f, 0.25f, 0.75f };
    private class AmbientOcclusion_Matrix
    {
        public static Matrix4x4 PrevViewProj;
    }

    private static int ssrID = Shader.PropertyToID("_AO_ColorMask_RT");

    public AmbientOcclusionRenderPass(KaiserAmbientOcclusion.Settings settings)
    {
        this.settings = settings;
        renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
        randomSampler = new RandomSampler(0, 1024);
        profilingSampler = new ProfilingSampler("[Kaiser RP] AmbientOcclusion");


    }

    // public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
    // {
    //     ConfigureInput(ScriptableRenderPassInput.Depth | ScriptableRenderPassInput.Normal);
    // }

    void UpdatePreviousTransformMatrix(CommandBuffer cmd, RenderingData renderingData)
    {
        AmbientOcclusion_Matrix.PrevViewProj =
            renderingData.cameraData.GetGPUProjectionMatrix() *
            renderingData.cameraData.GetViewMatrix();

        cmd.SetComputeMatrixParam(settings.computeShader, "_AO_PrevViewProjMatrix", AmbientOcclusion_Matrix.PrevViewProj);
    }

    public void InitializeRTHandles(int width, int height)
    {
        RenderTextureDescriptor descriptor = new RenderTextureDescriptor(width, height, RenderTextureFormat.ARGB32, 0);
        descriptor.enableRandomWrite = true;

        RenderingUtils.ReAllocateIfNeeded(ref AmbientOcclusion_Output.ColorMask, descriptor, FilterMode.Point, TextureWrapMode.Clamp, name: "_AO_RT");
        RenderingUtils.ReAllocateIfNeeded(ref AmbientOcclusion_Output.TemporalPrev, descriptor, FilterMode.Point, TextureWrapMode.Clamp, name: "_AO_HistoryBuffer0_RT");
        RenderingUtils.ReAllocateIfNeeded(ref AmbientOcclusion_Output.TemporalCurr, descriptor, FilterMode.Point, TextureWrapMode.Clamp, name: "_AO_HistoryBuffer1_RT");
        RenderingUtils.ReAllocateIfNeeded(ref AmbientOcclusion_Output.SpatialOut, descriptor, FilterMode.Point, TextureWrapMode.Clamp, name: "_AO_SpatialOut_RT");

    }

    public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
    {
        int width = renderingData.cameraData.camera.pixelWidth;
        int height = renderingData.cameraData.camera.pixelHeight;
        if (settings.resolution == KaiserAmbientOcclusion.Resolution.Half)
        {
            width /= 2;
            height /= 2;
        }
        InitializeRTHandles(width, height);
        // UpdatePreviousTransformMatrix(cmd, renderingData);
    }

    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        var cmd = CommandBufferPool.Get();

        using (new ProfilingScope(cmd, profilingSampler))
        {
            randomSampler.RefreshFrame();

            int width = renderingData.cameraData.camera.pixelWidth;
            int height = renderingData.cameraData.camera.pixelHeight;

            int k1 = settings.computeShader.FindKernel("GTAO");
            // int k2 = settings.computeShader.FindKernel("AO_TemporalFilter");
            // int k3 = settings.computeShader.FindKernel("AO_SpatialFilter");

            if (settings.resolution == KaiserAmbientOcclusion.Resolution.Half)
            {
                width /= 2;
                height /= 2;
            }
            int threadGroupsX = Mathf.CeilToInt(width / 8.0f);
            int threadGroupsY = Mathf.CeilToInt(height / 8.0f);

            var source = renderingData.cameraData.renderer.cameraColorTargetHandle;// renderingData.cameraData.renderer.GetCameraColorBackBuffer(cmd);
                                                                                   // var source = renderingData.cameraData.renderer.GetCameraColorBackBuffer(cmd);


            // cmd.SetComputeMatrixParam(settings.computeShader, "_AO_PrevViewProjMatrix", renderingData.cameraData.camera.previousViewProjectionMatrix);

            cmd.SetComputeVectorParam(settings.computeShader, "_AO_BufferSize", new Vector4(width, height, 1.0f / width, 1.0f / height));
            cmd.SetComputeIntParam(settings.computeShader, "_AO_FrameIndex", randomSampler.frameIndex);
            cmd.SetComputeVectorParam(settings.computeShader, "_AO_Jitter", randomSampler.GetRandomOffset());
            cmd.SetComputeVectorParam(settings.computeShader, "_AO_Random", new Vector4(Random.value, Random.value, Random.value, Random.value));

            cmd.SetComputeIntParam(settings.computeShader, "_AO_SliceCount", settings.sliceCount);
            cmd.SetComputeIntParam(settings.computeShader, "_AO_DirectionCount", settings.directionCount);
            cmd.SetComputeFloatParam(settings.computeShader, "_AO_Radius", settings.radius);
            cmd.SetComputeFloatParam(settings.computeShader, "_AO_TemporalOffsets", spatialOffsets[randomSampler.frameIndex / 6 % 4]);
            cmd.SetComputeFloatParam(settings.computeShader, "_AO_TemporalDirections", temporalRotations[randomSampler.frameIndex % 6]);


            cmd.SetComputeFloatParam(settings.computeShader, "_AO_Intensity", settings.intensity);

            float fovRad = renderingData.cameraData.camera.fieldOfView * Mathf.Deg2Rad;
            float halfProjScale = height / (Mathf.Tan(fovRad * 0.5f) * 2) * 0.5f;
            cmd.SetComputeFloatParam(settings.computeShader, "_AO_HalfProjScale", halfProjScale);
            Debug.Log(halfProjScale);

            cmd.SetComputeTextureParam(settings.computeShader, k1, "_AO_In_SceneColor_RT", source);
            cmd.SetComputeTextureParam(settings.computeShader, k1, "_AO_In_BlueNoise_RT", settings.blueNoise);
            cmd.SetComputeTextureParam(settings.computeShader, k1, "_AO_ColorMask_RT", AmbientOcclusion_Output.ColorMask);
            cmd.DispatchCompute(settings.computeShader, k1, threadGroupsX, threadGroupsY, 1);



            Blitter.BlitCameraTexture(cmd, AmbientOcclusion_Output.ColorMask, renderingData.cameraData.renderer.cameraColorTargetHandle);
            // Blitter.BlitCameraTexture(cmd, AmbientOcclusion_Output.HistoryBuffer[(historyIndex + 1) % 2], AmbientOcclusion_Output.HistoryBuffer[historyIndex]);
        }

        UpdatePreviousTransformMatrix(cmd, renderingData);

        context.ExecuteCommandBuffer(cmd);
        cmd.Clear();
        CommandBufferPool.Release(cmd);
    }
    public void Dispose()
    {
        // AmbientOcclusion_Output.ColorMask?.Release();
        // AmbientOcclusion_Output.TemporalPrev?.Release();
        // AmbientOcclusion_Output.TemporalCurr?.Release();
    }
    // public override void FrameCleanup(CommandBuffer cmd)
    // {
    //     // RTHandles.Release(AmbientOcclusion_Output.ColorMask);
    //     // AmbientOcclusion_Output.ColorMask?.Release();
    //     if (AmbientOcclusion_Output.ColorMask != null)
    //         cmd.ReleaseTemporaryRT(Shader.PropertyToID(AmbientOcclusion_Output.ColorMask.name));
    //     if (AmbientOcclusion_Output.TemporalPrev != null)
    //         cmd.ReleaseTemporaryRT(Shader.PropertyToID(AmbientOcclusion_Output.TemporalPrev.name));
    //     if (AmbientOcclusion_Output.TemporalCurr != null)
    //         cmd.ReleaseTemporaryRT(Shader.PropertyToID(AmbientOcclusion_Output.TemporalCurr.name));

    // }

    // public override void OnCameraCleanup(CommandBuffer cmd)
    // {
    //     AmbientOcclusion_Output.ColorMask = null;
    //     AmbientOcclusion_Output.TemporalPrev = null;
    //     AmbientOcclusion_Output.TemporalCurr = null;
    // }
}