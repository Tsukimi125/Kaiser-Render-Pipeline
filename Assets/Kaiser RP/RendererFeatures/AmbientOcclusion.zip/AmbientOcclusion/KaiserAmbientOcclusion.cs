using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class KaiserAmbientOcclusion : ScriptableRendererFeature
{
    public enum AmbientOcclusionType
    {
        HBAO,
        GTAO,
    }
    public enum Resolution
    {
        Half,
        Full,
    }

    [System.Serializable]
    public class Settings
    {

        public AmbientOcclusionType aoType = AmbientOcclusionType.GTAO;
        public ComputeShader computeShader;
        public Resolution resolution = Resolution.Half;
        public Texture2D blueNoise;
        [Range(0, 4)]
        public float intensity = 1.0f;
        [Range(0, 10)]
        public float radius = 1.5f;
        [Range(1, 10)]
        public int directionCount = 8;
        [Range(1, 10)]
        public int sliceCount = 8;



        // public RayTracingShader rayTracingShader;
    }

    public AmbientOcclusionRenderPass aoRenderPass;
    public Settings settings = new Settings();
    public override void Create()
    {
        aoRenderPass = new AmbientOcclusionRenderPass(settings);
    }
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (renderingData.cameraData.camera.cameraType == CameraType.Game)
        {
            renderer.EnqueuePass(aoRenderPass);
        }
    }

    public override void SetupRenderPasses(ScriptableRenderer renderer, in RenderingData renderingData)
    {
        aoRenderPass.ConfigureInput(ScriptableRenderPassInput.Color);
        // reflectionRenderPass.Setup(renderer.cameraColorTarget);
    }
    /// <inheritdoc/>
    protected override void Dispose(bool disposing)
    {
        aoRenderPass.Dispose();
    }


}
